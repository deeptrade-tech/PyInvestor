# PyInvestor

[![](https://travis-ci.com/SamurAi-sarl/PyInvestor.svg?token=1ybw2N4PGqXLfqpxx5kG&branch=master)]()
[![](https://img.shields.io/github/license/SamurAi-sarl/PyInvestor.svg)](https://github.com/SamurAi-sarl/PyInvestor)


PyInvestor is a python wrapper for the IEX package.

## What is PyInvestor
.....

## Basic Installation

